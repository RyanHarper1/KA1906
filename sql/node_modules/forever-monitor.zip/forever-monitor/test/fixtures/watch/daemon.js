console.log('Hello!');
//timeout should be large enough to stay alive during the test
setTimeout(process.exit, 20000);

