<?php
header('Location: PaymentSettlements/index.php');
?>